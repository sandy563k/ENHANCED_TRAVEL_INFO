const express = require('express');
const googleMapsClient = require('@google/maps').createClient({
    key: 'AIzaSyDQbQLlbMxDXov2qKWz7HO0fPMhDgH8OT4'
  });
var router = express.Router();
var ObjectId = require('mongoose').Types.ObjectId;

//added new
// Load the node-import first.
require('node-import');
 
// Include people.
var people = include('people');     // Valid
 
// Equal with
var people = require('./people/index.js');



var { Employee } = require('../models/employee');
//var directionsService = googleMapsClient.DirectionsService;

router.post('/',(req,res) =>{
  googleMapsClient.directions({
    //origin: '40.730610, -73.935242',
    //destination: '42.880230, -78.878738'
      origin: req.body.origin,
      destination: req.body.destination,
      mode: req.body.travelMode
  }, function(err, response) {
    if (!err) {
      console.log(response.json);
      res.send(response.json);
    }
  });

 /*getDirections(req, function(result){
    console.log("Response: ", result.json);
    res.send(result.json);
    });*/

});

function getDirections (req, callback)  {
  googleMapsClient.directions({
  origin: req.body.origin,
  destination: req.body.destination,
  mode: req.body.travelMode,

  }, function(err, response) {
  //console.log(err);
  //console.log(response);
    if (!err) { 
    callback(response.json.results);
    };
  });
};

function calculateAndDisplayRoute(directionsService,emp) {
    directionsService.route({
      origin: emp.src,
      destination: emp.destination,
      travelMode: 'DRIVING'
    }, function(response, status) {
      if (status === 'OK') {
        //directionsDisplay.setDirections(response);
      } else {
        window.alert('Directions request failed due to ' + status);
      }
    });
  }

module.exports = router;
